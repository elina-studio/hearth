' The MilkDrop looks the Visualizer can show (made from tools/viz/looks.json; the NucBox renders them,
' the NAS keeps a ready-made loop of each). Pictures for the picker: pkg:/images/music/viz/<n>.jpg
' Registry "hearth": vizLook = "shuffle" (default) or a look number; vizStars = starred numbers, comma separated.
function vizLooks() as object
    return [
        { n: "3", label: "Wanderer in curved space" },
        { n: "8", label: "Mig 85" },
        { n: "10", label: "Airhandler" },
        { n: "14", label: "Tack tiles" },
        { n: "17", label: "Cubetrace" },
        { n: "18", label: "Skylight" },
        { n: "25", label: "Pogo cubes" },
        { n: "30", label: "Area 51" },
        { n: "35", label: "Why the sky looks different" },
        { n: "40", label: "Truly soft" },
        { n: "53", label: "Star of Annon" },
        { n: "54", label: "Spiral movement" },
        { n: "56", label: "Acid wiring" },
        { n: "57", label: "Angel flight" },
        { n: "58", label: "Another kind of groove" },
        { n: "59", label: "Bombyx mori" },
        { n: "60", label: "Castle in the air" },
        { n: "61", label: "Chain breaker" },
        { n: "62", label: "Charisma" },
        { n: "63", label: "Disco mix" },
        { n: "65", label: "Frosty caves" },
        { n: "73", label: "Surface turbulence" },
        { n: "74", label: "Reflections on black tiles" },
        { n: "75", label: "Stormy sea" },
        { n: "77", label: "Witchcraft" },
        { n: "78", label: "Fata morgana" },
        { n: "79", label: "Enterstate" },
        { n: "83", label: "Fractal drop" },
        { n: "94", label: "Rewop" },
        { n: "98", label: "Star ornament" },
        { n: "99", label: "True visionary" },
        { n: "101", label: "Passage" },
        { n: "102", label: "Prismo" },
        { n: "103", label: "Starfield sectors" },
        { n: "104", label: "Explosive minds" },
        { n: "105", label: "Planet" },
        { n: "106", label: "Infinity" },
        { n: "107", label: "Royal mashup" },
        { n: "108", label: "Hexcollie" },
        { n: "109", label: "Spark" },
        { n: "110", label: "In da mash" },
        { n: "111", label: "Disco mashup" },
        { n: "112", label: "Toffee and icing" },
        { n: "113", label: "Dark galaxy" },
        { n: "114", label: "Potion of ink" },
        { n: "115", label: "Diabolo" },
        { n: "116", label: "Stitchcraft" },
        { n: "117", label: "Witchcraft 2" },
        { n: "118", label: "Disconnected" },
        { n: "119", label: "Bouncing balls" },
        { n: "120", label: "Rainbow pools" },
        { n: "121", label: "Ghost city" },
        { n: "122", label: "Amulet" },
        { n: "123", label: "Big guns" },
        { n: "124", label: "Neon blobs" },
        { n: "125", label: "Let it grow" },
        { n: "126", label: "Moss tide" },
        { n: "127", label: "Riverbed" },
        { n: "128", label: "Fern curl" },
        { n: "129", label: "Green hollow" },
        { n: "130", label: "Seed light" },
        { n: "131", label: "Driftwood" },
        { n: "132", label: "Bark" },
        { n: "133", label: "Root lines" },
        { n: "134", label: "Amber stream" },
        { n: "135", label: "Lichen quilt" },
        { n: "136", label: "Willow stems" },
        { n: "137", label: "Leaf cells" }
    ]
end function

function vizLabel(n as string) as string
    for each l in vizLooks()
        if l.n = n then return l.label
    end for
    return ""
end function

function vizChoice() as string
    c = CreateObject("roRegistrySection", "hearth").Read("vizLook")
    if c = "" or vizLabel(c) = "" then c = "shuffle"
    return c
end function

sub vizSetChoice(c as string)
    r = CreateObject("roRegistrySection", "hearth")
    r.Write("vizLook", c)
    r.Flush()
end sub

' starred looks as { "57": true, ... }
function vizStars() as object
    out = {}
    raw = CreateObject("roRegistrySection", "hearth").Read("vizStars")
    for each part in raw.Tokenize(",")
        if vizLabel(part) <> "" then out[part] = true
    end for
    return out
end function

sub vizSetStar(n as string, on as boolean)
    s = vizStars()
    if on then s[n] = true else s.Delete(n)
    r = CreateObject("roRegistrySection", "hearth")
    r.Write("vizStars", s.Keys().Join(","))
    r.Flush()
end sub

' Hearts are kept under the old registry name vizStars, so looks starred before stay hearted.
function vizHearts() as object
    return vizStars()
end function

sub vizSetHeart(n as string, on as boolean)
    vizSetStar(n, on)
end sub

' Play setting: "hearted" or "all" (registry hearth/vizPlay). Unset: hearted once any look is hearted.
function vizPlayMode() as string
    md = CreateObject("roRegistrySection", "hearth").Read("vizPlay")
    if md <> "hearted" and md <> "all"
        if vizHearts().Count() > 0 then md = "hearted" else md = "all"
    end if
    return md
end function

sub vizSetPlayMode(md as string)
    r = CreateObject("roRegistrySection", "hearth")
    r.Write("vizPlay", md)
    r.Flush()
end sub

' the looks that Shuffle, Next and Left/Right go through, in list order
function vizPool() as object
    hearts = vizHearts()
    useHearts = (vizPlayMode() = "hearted" and hearts.Count() > 0)
    pool = []
    for each l in vizLooks()
        if not useHearts or hearts[l.n] = true then pool.push(l.n)
    end for
    return pool
end function

' the look for a song: the one picked, or a random one from the pool (hearted looks, or all)
function vizPick() as string
    c = vizChoice()
    if c <> "shuffle" then return c
    pool = vizPool()
    return pool[Rnd(pool.Count()) - 1]
end function
