' Geometry (1920 x 930 under the pills): PEEK px of the neighbours show at each edge, VIS panels of
' W px fill the middle, RULE px dividers sit between. The focused panel is kept in the middle slot
' (or nearer the first/last slot at the ends) by sliding the whole strip. With VIS or fewer moods the
' strip sits centred and nothing slides.
sub init()
    m.H = 930
    m.RULE = 24
    m.PEEK = 80
    m.VIS = 5
    m.PAD = 28
    m.W = Int((1920 - (m.VIS + 1) * m.RULE - 2 * m.PEEK) / m.VIS)
    m.active = false
    m.strip = m.top.findNode("strip")
    m.dotsGroup = m.top.findNode("dots")
    m.clipsAsked = false
    ' true once Plex has said which clips there are; only then can a mood say "no clip yet"
    m.clipsKnown = false
    build(ambItems(), CreateObject("roRegistrySection", "hearth").Read("ambLast"))
    m.slideTo = m.top.findNode("slideTo")
    m.slide = m.top.findNode("slide")
    m.strip.translation = [stripX(), 0]
    paint()
    loadClips()
end sub

' (Re)build the panels, dividers and dots for a list of moods, focusing the one named keep.
sub build(items as object, keep as string)
    m.items = items
    m.n = items.count()
    m.index = 0
    for i = 0 to m.n - 1
        if m.items[i].mood = keep then m.index = i
    end for
    m.strip.removeChildrenIndex(m.strip.getChildCount(), 0)
    m.dotsGroup.removeChildrenIndex(m.dotsGroup.getChildCount(), 0)
    m.panels = []
    for i = 0 to m.n - 1
        m.panels.push(makePanel(i))
        if i < m.n - 1
            r = m.strip.createChild("Poster")
            r.uri = "pkg:/images/amb/divider.png"
            r.width = m.RULE
            r.height = m.H
            r.translation = [panelX(i) + m.W, 0]
        end if
    end for
    m.dots = []
    for i = 0 to m.n - 1
        dt = m.dotsGroup.createChild("Rectangle")
        dt.width = 12
        dt.height = 12
        dt.translation = [960 - (m.n * 26) / 2 + i * 26, m.H - 26]
        m.dots.push(dt)
    end for
    m.strip.translation = [stripX(), 0]
end sub

' A Plex picture cropped to the panel's shape (Plex scales it to cover, the Poster trims the rest).
function plexStill(path as string) as string
    ' a picture the NAS helper took from the clip itself
    if Left(path, 4) = "http" then return path
    w = 760
    h = 930
    if CreateObject("roDeviceInfo").GetUIResolution().name = "HD"
        w = 507
        h = 620
    end if
    return m.global.plexServer + "/photo/:/transcode?width=" + w.toStr() + "&height=" + h.toStr() + "&minSize=1&upscale=1&url=" + hEscape(path) + "&X-Plex-Token=" + m.global.plexServerToken
end function

' Ask Plex for the clips in the "Ambiance" library once it's known.
sub loadClips()
    if m.clipsAsked then return
    libs = m.global.libraries
    if libs = invalid or libs.Count() = 0
        print "[ambiance] Plex libraries not loaded yet"
        return
    end if
    m.clipsAsked = true
    ' no Ambiance library: PlexTask looks for a hearth folder inside the movie libraries instead
    sec = ""
    if libs.ambiance <> invalid then sec = libs.ambiance
    print "[ambiance] asking Plex for clips, library '"; sec; "'"
    hPlex("clips", { section: sec }, "onClips")
end sub

sub onClips(event as object)
    t = hTaskFrom(event)
    m.top.ready = true
    if not t.ok or t.response.Clips = invalid
        print "[ambiance] clips request failed, status "; t.status
        m.clipsAsked = false
        return
    end if
    print "[ambiance] plex clips: "; t.response.Clips.count()
    m.clipsKnown = true
    ' a clip the NAS is still getting ready: ask again the next time the room is looked at
    prep = t.response.Preparing
    if prep <> invalid and prep.count() > 0 then m.clipsAsked = false
    if t.response.Clips.count() = 0 and (prep = invalid or prep.count() = 0)
        build(ambMoods(), m.items[m.index].mood)
        paint()
        return
    end if
    items = ambMerge(t.response.Clips, prep)
    if not m.global.hasField("ambItems") then m.global.addFields({ ambItems: [] })
    m.global.ambItems = items
    keep = m.items[m.index].mood
    build(items, keep)
    paint()
end sub

function panelX(i as integer) as integer
    return i * (m.W + m.RULE)
end function

' strip offset that keeps the focused panel in the middle slot when it can be
function stripX() as integer
    if m.n <= m.VIS then return Int((1920 - (m.n * m.W + (m.n - 1) * m.RULE)) / 2)
    first = m.index - Int(m.VIS / 2)
    if first < 0 then first = 0
    if first > m.n - m.VIS then first = m.n - m.VIS
    return m.PEEK + m.RULE - panelX(first)
end function

function makePanel(i as integer) as object
    it = m.items[i]
    p = {}
    g = m.strip.createChild("Group")
    g.translation = [panelX(i), 0]
    p.group = g
    pic = g.createChild("Poster")
    pic.width = m.W
    pic.height = m.H
    pic.loadDisplayMode = "scaleToZoom"
    ' decode at the TV's real 720p size, not the file's
    pic.loadWidth = Int(m.W * 2 / 3)
    pic.loadHeight = Int(m.H * 2 / 3)
    pic.uri = it.still
    if it.plexStill <> invalid and it.plexStill <> "" then pic.uri = plexStill(it.plexStill)
    ' a built-in mood with no clip of the person's own: a dashed panel with the file name to add
    hint = clipHint(it.mood)
    if m.clipsKnown and it.clip = invalid and it.preparing = true
        missingPanel(g, "Your clip is being made ready for the TV")
    else if m.clipsKnown and it.clip = invalid and hint <> ""
        missingPanel(g, "Drawn scene · your own clip replaces it")
    end if
    top = g.createChild("Poster")
    top.uri = "pkg:/images/amb/shade-top.png"
    top.width = m.W
    top.height = 420
    bot = g.createChild("Poster")
    bot.uri = "pkg:/images/shade.png"
    bot.width = m.W
    bot.height = 220
    bot.translation = [0, m.H - 220]
    p.bottomShade = bot
    num = g.createChild("Label")
    num.font = hFont("caps", 34)
    num.translation = [m.PAD, 40]
    nn = (i + 1).toStr()
    if i + 1 < 10 then nn = "0" + nn
    num.text = nn
    p.num = num
    t = g.createChild("Label")
    ' your own clips can have long names: step the size down so they stay on one line
    ' step the size down until the whole name fits (UX review item 5: "LIGHTS O..." was cut off)
    ' narrow panels: one line when it fits, two lines at the smallest size when it doesn't
    t.translation = [m.PAD, 84]
    fit = hFitTitle2(t, UCase(it.title), "caps", [60, 52, 46, 40], m.W - 2 * m.PAD)
    p.title = t
    s = g.createChild("Label")
    s.font = hFont("fell", 30)
    s.color = "0xB5AF8CFF"
    ' the line sits a fixed 10 px under the title, however tall the title came out
    s.translation = [m.PAD, 84 + fit.height + 10]
    s.width = m.W - 2 * m.PAD
    s.wrap = true
    s.maxLines = 2
    s.text = it.sub
    ' controls on the focused panel: OK Play, and the sound state
    c = g.createChild("Group")
    c.translation = [m.PAD, m.H - 136]
    ok = c.createChild("Poster")
    ok.uri = "pkg:/images/amb/icon-ok.png"
    ok.width = 62
    ok.height = 44
    lab = c.createChild("Label")
    lab.font = hFont("regular", 26)
    lab.color = "0xB5AF8CFF"
    lab.translation = [76, 6]
    if it.mood = "window" then lab.text = "Open" else lab.text = "Play"
    snd = c.createChild("Poster")
    snd.width = 46
    snd.height = 34
    snd.translation = [8, 61]
    sl = c.createChild("Label")
    sl.font = hFont("regular", 26)
    sl.color = "0xB5AF8CFF"
    sl.translation = [76, 62]
    p.soundIcon = snd
    p.soundLabel = sl
    p.controls = c
    bar = g.createChild("Rectangle")
    bar.width = m.W
    bar.height = 6
    bar.color = "0xE0B34AFF"
    bar.translation = [0, m.H - 6]
    p.bar = bar
    p.mood = it.mood
    return p
end function

' The file-name start ambClipMood matches for each built-in mood ("" = no hint)
function clipHint(md as string) as string
    pre = { hearth: "fire", rain: "rain", fireflies: "firefly", lightsout: "embers" }
    if pre[md] = invalid then return ""
    return pre[md] + "-anything.mp4"
end function

' A built-in mood with no clip of the person's own keeps its drawn scene (UX review item 5): no dashed setup box.
' One quiet line says the drawn scene is standing in; the file name to add lives in the mood's * options.
sub missingPanel(g as object, words as string)
    a = g.createChild("Label")
    a.font = hFont("regular", 24)
    a.color = "0xB5AF8CCC"
    a.width = m.W - 2 * m.PAD
    a.wrap = true
    a.maxLines = 2
    a.translation = [m.PAD, m.H - 230]
    a.text = words
end sub

sub paint()
    reg = CreateObject("roRegistrySection", "hearth")
    for i = 0 to m.n - 1
        p = m.panels[i]
        foc = (i = m.index)
        lit = foc and m.active
        if lit
            p.title.color = "0xE0B34AFF"
            p.num.color = "0xE0B34AFF"
            p.group.opacity = 1.0
        else
            p.title.color = "0xEDE6CAFF"
            p.num.color = "0xB5AF8CFF"
            if foc then p.group.opacity = 1.0 else p.group.opacity = 0.55
        end if
        p.bar.visible = lit
        p.controls.visible = lit
        p.bottomShade.visible = lit
        if p.mood = "window"
            p.soundIcon.visible = false
            p.soundLabel.visible = false
        else
            on = (reg.Read("ambSound_" + p.mood) <> "0")
            if on then p.soundIcon.uri = "pkg:/images/amb/icon-sound-on.png" else p.soundIcon.uri = "pkg:/images/amb/icon-sound-off.png"
            if on then p.soundLabel.text = "Sound on" else p.soundLabel.text = "Sound off"
        end if
    end for
    for i = 0 to m.n - 1
        if i = m.index then m.dots[i].color = "0xE0B34AFF" else m.dots[i].color = "0x464638FF"
    end for
end sub

sub focusIn(unused as dynamic)
    loadClips()
    m.active = true
    paint()
    m.top.setFocus(true)
end sub

' sound settings can change inside a mood; repaint when we come back
sub refresh(unused as dynamic)
    loadClips()
    paint()
end sub

sub move(d as integer)
    i = m.index + d
    if i < 0 or i >= m.n then return
    m.index = i
    m.slideTo.keyValue = [m.strip.translation, [stripX(), 0]]
    m.slide.control = "start"
    paint()
end sub

function hKeyInner(key as string, press as boolean) as boolean
    if hMediaKey(key) then return false
    if not press then return false
    if key = "left"
        move(-1)
        return true
    else if key = "right"
        move(1)
        return true
    else if key = "OK"
        it = m.items[m.index]
        if it.mood = "window"
            m.top.request = { action: "room", name: "Photos" }
        else
            m.top.request = { action: "mood", mood: it.mood }
        end if
        return true
    else if key = "options"
        clipInfo(m.items[m.index])
        return true
    else if key = "up" or key = "back"
        m.active = false
        paint()
        m.top.request = { action: "pills" }
        return true
    end if
    return true
end function

' * on a mood: where its picture comes from, and how to use your own clip instead
sub clipInfo(it as object)
    d = CreateObject("roSGNode", "HearthDialog")
    d.title = it.title
    hint = clipHint(it.mood)
    if it.clip <> invalid
        d.message = ["Playing your own clip: " + it.clip.Name]
        if it.mood = "lightsout" and ambClipMood(it.clip.file) <> "lightsout" then d.message = ["No embers clip found, so this plays your fire clip: " + it.clip.Name]
    else if it.preparing = true
        d.message = ["Your clip is in the hearth folder and the NAS is making a copy this TV can play. It shows here when it is ready."]
    else if hint <> ""
        d.message = ["This mood shows a drawn scene.", "To use your own clip, add a video to the Plex Ambiance library named " + hint]
    else
        d.message = [it.sub]
    end if
    d.buttons = ["Close"]
    d.kinds = ["main"]
    pic = "pkg:/images/amb/col-window.jpg"
    if it.mood = "hearth" or it.mood = "rain" or it.mood = "lightsout" or it.mood = "fireflies" or it.mood = "window" then pic = "pkg:/images/amb/tile-" + it.mood + ".jpg"
    d.hero = { art: pic, shape: "square", kicker: "Ambiance" }
    d.observeField("buttonSelected", "onClipInfoClosed")
    d.observeField("wasClosed", "onClipInfoClosed")
    m.clipDialog = d
    hShowDialog(d)
end sub

sub onClipInfoClosed()
    if m.clipDialog <> invalid then m.clipDialog.close = true
    m.top.setFocus(true)
end sub

' menu sound for whatever the handler above took (source/util.brs hKeySfx)
function onKeyEvent(key as string, press as boolean) as boolean
    return hKeySfx(key, press, hKeyInner(key, press))
end function
