' Requests room (layout B: rail and grid, Search first; P1 poster-card popup).
' Zones: "rail", "grid", "bar" (filter bar), "sheet" (filter sheet), "kb" (search keyboard), "results" (search results), "popup", "setup", "save".

sub init()
    m.reg = CreateObject("roRegistrySection", "hearth")
    m.rail = m.top.findNode("rail")
    m.grid = m.top.findNode("grid")
    m.empty = m.top.findNode("empty")
    m.empty.font = hFont("regular", 28)
    m.eyebrow = m.top.findNode("eyebrow")
    m.eyebrow.font = hFont("caps", 28)
    m.rating = m.top.findNode("rating")
    m.rating.font = hFont("caps", 28)
    m.star = m.top.findNode("star")
    m.title = m.top.findNode("title")
    m.title.font = hFont("caps", 60)
    m.top.findNode("musicTitle").font = hFont("caps", 44)
    m.top.findNode("musicSub").font = hFont("regular", 26)
    m.searchPanel = m.top.findNode("searchPanel")
    m.musicPanel = m.top.findNode("musicPanel")
    m.kb = m.top.findNode("kb")
    m.kb.observeField("text", "onKbText")
    m.results = m.top.findNode("results")
    m.resultsHead = m.top.findNode("resultsHead")
    m.resultsHead.font = hFont("regular", 28)
    m.setup = m.top.findNode("setup")
    m.setupText = m.top.findNode("setupText")
    m.setupText.font = hFont("regular", 28)
    m.keyKb = m.top.findNode("keyKb")
    m.saveKey = m.top.findNode("saveKey")
    m.toast = m.top.findNode("toast")
    m.toastText = m.top.findNode("toastText")
    m.toastText.font = hFont("bold", 30)
    m.toastHint = m.top.findNode("toastHint")
    m.toastHint.font = hFont("regular", 26)
    m.popupHolder = m.top.findNode("popupHolder")
    m.top.findNode("toastTimer").observeField("fire", "onToastDone")
    m.top.findNode("undoTimer").observeField("fire", "onUndoTick")
    m.top.findNode("detailTimer").observeField("fire", "onDetailTimer")
    m.top.findNode("searchTimer").observeField("fire", "runSearch")
    m.top.findNode("pollTimer").observeField("fire", "onPoll")
    m.mineSig = ""
    m.mineActive = false

    m.lists = [
        { key: "search", icon: "search", name: "Search", about: "TYPE A TITLE" },
        { key: "new", icon: "down", name: "New", about: "NEWLY DOWNLOADED · NEWEST FIRST" },
        { key: "trending", icon: "spark", name: "Trending", about: "TRENDING THIS WEEK", path: "/api/v1/discover/trending" },
        { key: "movies", icon: "film", name: "Popular movies", about: "POPULAR MOVIES", path: "/api/v1/discover/movies" },
        { key: "tv", icon: "tv", name: "Popular shows", about: "POPULAR SHOWS", path: "/api/v1/discover/tv" },
        { key: "upcoming", icon: "cal", name: "Coming soon", about: "MOVIES COMING SOON", path: "/api/v1/discover/movies/upcoming" },
        { key: "mine", icon: "clock", name: "Your requests", about: "WHAT YOU'VE ASKED FOR" },
        { key: "music", icon: "note", name: "Music", about: "LIDARR" }
    ]
    m.cards = {}
    m.details = {}
    m.tasks = {}
    m.railIndex = 2
    m.gridIndex = 0
    m.resIndex = 0
    ' New: All / Movies / Shows / Music
    m.newTabs = [{ key: "", icon: "layers", name: "All" }, { key: "movie", icon: "film", name: "Movies" }, { key: "tv", icon: "tv", name: "Shows" }, { key: "music", icon: "note", name: "Music" }]
    m.newTab = 0
    m.newAll = invalid
    m.tabs = m.top.findNode("tabs")
    m.gridClip = m.top.findNode("gridClip")
    m.zone = "rail"
    m.focused = false
    m.loaded = false
    m.pending = invalid
    m.problem = ""
    m.cols = 6
    m.pitchX = 212
    m.pitchY = 370
    m.query = ""
    m.wantPopup = ""
    m.ver = 0
    m.builtFor = ""
    ' Discover lists: up to 5 pages (about 100 titles), narrowed by the filter sheet
    m.filters = { trending: newFilters("all"), movies: newFilters("movie"), tv: newFilters("tv") }
    m.gen = {}
    m.acc = {}
    m.seen = {}
    m.pageNo = {}
    m.busy = {}
    m.inflight = {}
    m.fresh = {}
    m.more = {}
    m.totalPages = {}
    m.loadedAt = {}
    m.up = CreateObject("roTimespan")
    m.nodes = {}
    m.moreText = m.top.findNode("moreText")
    m.moreText.font = hFont("regular", 24)
    m.listError = {}
    m.genres = { movie: [], tv: [] }
    m.provs = { movie: [], tv: [] }
    m.rt = {}
    m.filterBar = m.top.findNode("filterBar")
    m.top.findNode("barLabel").font = hFont("bold", 26)
    m.top.findNode("barSum").font = hFont("regular", 24)
    m.top.findNode("barCount").font = hFont("regular", 24)
    m.top.findNode("barHint").font = hFont("regular", 22)
    m.totals = {}
    m.sheetHolder = m.top.findNode("sheetHolder")

    if not m.global.hasField("overseerrKey") then m.global.addFields({ overseerrKey: "" })
    m.global.observeField("overseerrKey", "onKeyArrived")
    buildRail()
    buildTabs()
    refresh(invalid)
end sub

' ================================================================ loading

sub refresh(unused as dynamic)
    if apiKey() = ""
        showSetup("")
        ' the NAS helper may hold the key (a reinstall, or the NAS was off at launch): ask it once per visit.
        ' When it has one, the key arrives through m.global.overseerrKey and this screen gives way to the room.
        if m.keysTask = invalid
            m.keysTask = CreateObject("roSGNode", "KeysTask")
            m.keysTask.observeField("done", "onKeysTried")
            m.keysTask.control = "RUN"
        end if
        return
    end if
    if m.setup.visible
        m.setup.visible = false
        m.top.findNode("main").visible = true
        m.zone = "rail"
    end if
    if not m.loaded
        m.loaded = true
        m.problem = ""
        for each l in m.lists
            if l.path <> invalid then loadList(l.key)
        end for
        oApi("GET", "/api/v1/genres/movie", invalid, invalid, "onGenres", "movie")
        oApi("GET", "/api/v1/genres/tv", invalid, invalid, "onGenres", "tv")
        oApi("GET", "/api/v1/watchproviders/movies", "watchRegion=" + watchRegion(), invalid, "onProviders", "movie")
        oApi("GET", "/api/v1/watchproviders/tv", "watchRegion=" + watchRegion(), invalid, "onProviders", "tv")
    end if
    loadMine()
    loadNew()
end sub

' New comes from Plex (what actually landed), so OK can open and play it
sub loadNew()
    if m.global.plexServer = invalid or m.global.plexServer = "" then return
    hPlex("arrived", { limit: 30 }, "onArrived")
end sub

sub onArrived(event as object)
    t = hTaskFrom(event)
    cards = []
    seen = {}
    if t.ok and t.response <> invalid and t.response.Items <> invalid
        for each it in t.response.Items
            key = it.Id
            if it.Type = "Episode" and it.SeriesId <> invalid then key = it.SeriesId
            if key <> invalid and seen[key] = invalid
                img = hImage(it, "Primary", 180)
                c = rqArrivedCard(it, img)
                if c <> invalid
                    seen[key] = true
                    cards.push(c)
                end if
            end if
        end for
    end if
    m.newAll = cards
    filterNew()
end sub

sub filterNew()
    if m.newAll = invalid then return
    want = m.newTabs[m.newTab].key
    out = []
    for each c in m.newAll
        if want = "" or c.data.kind = want then out.push(c)
    end for
    m.cards["new"] = out
    m.ver = m.ver + 1
    paintRail()
    if currentList().key = "new" then showList()
end sub

sub buildTabs()
    x = 0
    for each tb in m.newTabs
        g = m.tabs.createChild("Group")
        g.translation = [x, 0]
        ic = g.createChild("Poster")
        ic.uri = "pkg:/images/requests/" + tb.icon + ".png"
        ic.width = 24
        ic.height = 24
        ic.translation = [0, 14]
        lab = g.createChild("Label")
        lab.font = hFont("fell", 32)
        lab.text = tb.name
        lab.translation = [34, 0]
        lab.height = 52
        lab.vertAlign = "center"
        w = 34 + lab.boundingRect().width
        line = g.createChild("Rectangle")
        line.width = w
        line.height = 3
        line.translation = [0, 56]
        line.color = "0xE0B34AFF"
        x = x + w + 48
    end for
end sub

' Plain words, gold underline under the chosen one; brighter while the tabs have focus
sub paintTabs()
    for i = 0 to m.newTabs.count() - 1
        g = m.tabs.getChild(i)
        sel = (i = m.newTab)
        on = sel and m.focused and m.zone = "tabs"
        col = "0xB5AF8C99"
        if sel then col = "0xEDE6CAFF"
        if on then col = "0xE0B34AFF"
        if sel then g.getChild(0).blendColor = "0xE0B34AFF" else g.getChild(0).blendColor = "0xB5AF8C99"
        g.getChild(1).color = col
        g.getChild(2).visible = sel
        if on then g.getChild(2).height = 5 else g.getChild(2).height = 3
    end for
end sub

' Download bars: while Your requests is on screen and something is on its way, ask Overseerr again every 10 s
sub onPoll()
    if not m.focused or m.popup <> invalid or m.setup.visible then return
    if currentList().key <> "mine" or not m.mineActive then return
    loadMine()
end sub

sub loadMine()
    ' one at a time: each run fetches every request's title one by one, so a slow Overseerr must not pile them up
    if m.mineBusy = true then return
    m.mineBusy = true
    t = CreateObject("roSGNode", "OverseerrTask")
    t.mode = "requests"
    t.tag = "mine"
    keep(t, "onMine")
end sub

sub oApi(method as string, path as string, query as dynamic, body as dynamic, cb as string, tag as string)
    t = CreateObject("roSGNode", "OverseerrTask")
    t.method = method
    t.path = path
    if type(query) = "roString" or type(query) = "String"
        t.queryText = query
    else if query <> invalid
        t.query = query
    end if
    if body <> invalid
        if type(body) = "roString" or type(body) = "String" then t.bodyText = body else t.body = body
    end if
    t.tag = tag
    m.lastTask = t
    keep(t, cb)
end sub

sub keep(t as object, cb as string)
    key = "o" + Rnd(1000000).toStr()
    t.key = key
    m.tasks[key] = t
    t.observeField("done", cb)
    t.control = "RUN"
end sub

function taskFrom(event as object) as object
    t = event.getRoSGNode()
    if t.key <> invalid then m.tasks.delete(t.key)
    return t
end function

function apiKey() as string
    k = m.reg.Read("overseerrKey")
    if k = invalid then return ""
    return k
end function

function baseUrl() as string
    u = m.reg.Read("overseerrUrl")
    if u = invalid or u = "" then u = "http://192.168.254.41:5055"
    return u
end function

sub onKeysTried()
    ' free the slot so the next visit can ask again
    m.keysTask = invalid
end sub

sub onKeyArrived()
    m.loaded = false
    m.cards = {}
    m.ver = m.ver + 1
    refresh(invalid)
    if m.focused then focusIn(invalid)
    flash("check", "Overseerr key saved", "")
end sub

' Bad key or Overseerr down: say so in plain words
function checkProblem(t as object) as boolean
    if t.status = 401 or t.status = 403
        showSetup("Overseerr didn't accept the saved key (error " + t.status.toStr() + "). Send it again, or type it here.")
        return true
    end if
    if t.status <= 0
        m.problem = "Overseerr isn't answering at " + baseUrl() + ". Is its container running?"
        showList()
        return true
    end if
    return false
end function

sub onList(event as object)
    t = taskFrom(event)
    m.top.ready = true
    parts = t.tag.Split("|")
    key = parts[0]
    if m.gen[key] <> Val(parts[1]) then return
    m.busy[key] = false
    m.more[key] = false
    m.moreText.visible = false
    if checkProblem(t) then return
    if not t.ok
        if Val(parts[2]) = 1 and m.cards[key] = invalid
            m.problem = "Overseerr answered with error " + t.status.toStr() + ". Back out and in to try again."
            showList()
        else if Val(parts[2]) = 1
            ' a filter Overseerr wouldn't run: say so instead of leaving the old cards up as if nothing happened
            m.listError[key] = "Overseerr couldn't do that search (error " + t.status.toStr() + ")."
            m.acc[key] = []
            if m.fresh[key] = invalid then m.fresh[key] = 0
            m.fresh[key] = m.fresh[key] + 1
            publishList(key)
        end if
        return
    end if
    page = Val(parts[2])
    print "[hearth-filter] answer "; key; " page "; page; " status "; t.status; " ok "; t.ok
    for each c in discoverCards(t)
        id = c.data.mediaType + c.data.id.toStr()
        if m.seen[key][id] = invalid
            m.seen[key][id] = true
            m.acc[key].push(c)
        end if
    end for
    m.pageNo[key] = page
    m.more[key] = false
    m.inflight.delete(key)
    m.moreText.visible = false
    if page = 1
        if m.fresh[key] = invalid then m.fresh[key] = 0
        m.fresh[key] = m.fresh[key] + 1
    end if
    if t.response.totalResults <> invalid then m.totals[key] = t.response.totalResults
    if t.response.totalPages <> invalid then m.totalPages[key] = t.response.totalPages
    publishList(key)
    ' the second page comes straight away so there is always something past the first screen; the rest as you scroll
    if page = 1 then maybeMore(key)
end sub

sub publishList(key as string)
    m.cards[key] = clientFilter(key, m.acc[key])
    print "[hearth-filter] publish "; key; " "; m.cards[key].count(); " cards of "; m.acc[key].count()
    m.problem = ""
    paintRail()
    if currentList().key = key then showList()
end sub

function newFilters(kind as string) as object
    return { kind: kind, genres: [], provider: "", minRating: 0, sort: "popular" }
end function

' "movie" / "tv" for the list being narrowed; "all" for the plain Trending feed
function effKind(key as string) as string
    if key = "movies" then return "movie"
    if key = "tv" then return "tv"
    if key = "trending" then return m.filters.trending.kind
    return ""
end function

' Trending has no filters of its own in Overseerr; once narrowed it asks the movie or show Discover list instead
function listPath(key as string) as string
    if key = "trending"
        if m.filters.trending.kind = "movie" then return "/api/v1/discover/movies"
        if m.filters.trending.kind = "tv" then return "/api/v1/discover/tv"
    end if
    return listByKey(key).path
end function

function isFilterable(key as string) as boolean
    return key = "trending" or key = "movies" or key = "tv"
end function

function isDiscover(key as string) as boolean
    return key = "trending" or key = "movies" or key = "tv" or key = "upcoming"
end function

function watchRegion() as string
    r = m.reg.Read("watchRegion")
    if r = "" then r = "US"
    return r
end function

function listByKey(key as string) as object
    for each l in m.lists
        if l.key = key then return l
    end for
    return invalid
end function

' Start a list again from page 1 (new filters); the old cards stay up until page 1 arrives
sub loadList(key as string)
    if m.gen[key] = invalid then m.gen[key] = 0
    m.gen[key] = m.gen[key] + 1
    ' a search that is still running for the old filters is stopped, not just ignored
    stopList(key)
    m.acc[key] = []
    m.seen[key] = {}
    m.pageNo[key] = 0
    m.totalPages[key] = 0
    m.more[key] = false
    m.loadedAt[key] = m.up.TotalSeconds()
    m.busy[key] = true
    m.listError[key] = ""
    if currentList().key = key and isFilterable(key) then paintBar()
    fetchPage(key, 1)
end sub

sub stopList(key as string)
    t = m.inflight[key]
    if t <> invalid
        t.control = "STOP"
        if t.key <> invalid then m.tasks.delete(t.key)
        m.inflight.delete(key)
    end if
end sub

' Lists are asked again when you come back to them after a few minutes, so Trending and Popular stay fresh
sub touchList(key as string)
    if not isDiscover(key) or m.busy[key] = true or m.setup.visible then return
    if m.loadedAt[key] = invalid then return
    if m.up.TotalSeconds() - m.loadedAt[key] > 300
        print "[hearth-filter] refresh "; key; " (older than 5 minutes)"
        loadList(key)
    end if
end sub

' Near the end of the grid: ask Overseerr for the next page, as long as it has more
sub maybeMore(key as string)
    if not isDiscover(key) or m.more[key] = true or m.busy[key] = true then return
    if m.pageNo[key] = invalid or m.pageNo[key] < 1 then return
    if m.pageNo[key] >= m.totalPages[key] then return
    m.more[key] = true
    m.moreText.visible = true
    fetchPage(key, m.pageNo[key] + 1)
end sub

sub fetchPage(key as string, page as integer)
    ' The query goes as one text, not an assocarray: an assocarray lowercases its keys (sortBy -> sortby), and Overseerr
    ' ignores the lowercase versions, so every filter except genre silently did nothing.
    q = ["page=" + page.toStr()]
    addFilterQuery(q, key)
    qs = q.join("&")
    path = listPath(key)
    print "[hearth-filter] ask "; path; " page "; page; " ?"; qs
    oApi("GET", path, qs, invalid, "onList", key + "|" + m.gen[key].toStr() + "|" + page.toStr())
    m.inflight[key] = m.lastTask
end sub


' Movies and shows are narrowed by Overseerr itself; Trending can't be, so it is narrowed here (clientFilter)
sub addFilterQuery(q as object, key as string)
    if key <> "movies" and key <> "tv" and key <> "trending" then return
    f = m.filters[key]
    kind = effKind(key)
    if kind <> "movie" and kind <> "tv" then return
    ids = []
    for each name in f.genres
        id = genreId(kind, name)
        if id <> "" then ids.push(id)
    end for
    if ids.count() > 0 then qp(q, "genre", ids.join(","))
    if f.provider <> ""
        qp(q, "watchProviders", f.provider)
        qp(q, "watchRegion", watchRegion())
    end if
    votes = 0
    if f.minRating > 0
        qp(q, "voteAverageGte", f.minRating.toStr())
        votes = 50
    end if
    today = CreateObject("roDateTime").ToISOString().Left(10)
    if f.sort = "rating"
        qp(q, "sortBy", "vote_average.desc")
        if votes = 0 then votes = 300
    else if f.sort = "newest"
        if kind = "movie"
            qp(q, "sortBy", "primary_release_date.desc")
            qp(q, "primaryReleaseDateLte", today)
        else
            qp(q, "sortBy", "first_air_date.desc")
            qp(q, "firstAirDateLte", today)
        end if
        if votes = 0 then votes = 20
    else if f.sort = "az"
        if kind = "movie" then qp(q, "sortBy", "original_title.asc") else qp(q, "sortBy", "original_name.asc")
        if votes = 0 then votes = 20
    end if
    if votes > 0 then qp(q, "voteCountGte", votes.toStr())
end sub
sub qp(q as object, name as string, value as string)
    q.push(name + "=" + urlEnc(value))
end sub

' Percent-encodes by hand: roUrlTransfer can only be made on a Task thread, and this runs on the render thread
function urlEnc(s as string) as string
    out = ""
    hex = "0123456789ABCDEF"
    for i = 1 to Len(s)
        ch = Mid(s, i, 1)
        a = Asc(ch)
        if (a >= 48 and a <= 57) or (a >= 65 and a <= 90) or (a >= 97 and a <= 122) or ch = "-" or ch = "_" or ch = "." or ch = "~"
            out = out + ch
        else if a < 128
            out = out + "%" + Mid(hex, Int(a / 16) + 1, 1) + Mid(hex, (a mod 16) + 1, 1)
        else
            out = out + "%3F"
        end if
    end for
    return out
end function


function genreId(kind as string, name as string) as string
    for each g in m.genres[kind]
        if g.name = name then return g.id.toStr()
    end for
    return ""
end function

function clientFilter(key as string, cards as object) as object
    return cards
end function

function cardHasGenre(c as object, name as string) as boolean
    if c.genreIds = invalid then return false
    for each kind in ["movie", "tv"]
        id = genreId(kind, name)
        if id <> ""
            for each g in c.genreIds
                if g.toStr() = id then return true
            end for
        end if
    end for
    return false
end function

' Simple insertion sort (lists are about 100 long)
function sortCards(cards as object, field as string, desc as boolean) as object
    out = []
    for each c in cards
        v = c[field]
        if v = invalid
            if field = "vote" then v = 0 else v = ""
        end if
        i = out.count()
        while i > 0
            w = out[i - 1][field]
            if w = invalid
                if field = "vote" then w = 0 else w = ""
            end if
            before = false
            if desc then before = (v > w) else before = (LCase(v.toStr()) < LCase(w.toStr()))
            if not before then exit while
            i = i - 1
        end while
        ' roArray has no Insert: add at the end and shift the later ones up
        out.push(c)
        j = out.count() - 1
        while j > i
            out[j] = out[j - 1]
            j = j - 1
        end while
        out[i] = c
    end for
    return out
end function

sub onGenres(event as object)
    t = taskFrom(event)
    if t.ok and t.response.results <> invalid then m.genres[t.tag] = t.response.results
end sub

sub onProviders(event as object)
    t = taskFrom(event)
    if not (t.ok and t.response.results <> invalid) then return
    out = []
    wanted = [{ k: "netflix", n: "Netflix" }, { k: "max", n: "Max" }, { k: "disney", n: "Disney+" }, { k: "prime video", n: "Prime" }, { k: "apple tv", n: "Apple TV+" }, { k: "hulu", n: "Hulu" }, { k: "paramount", n: "Paramount+" }, { k: "peacock", n: "Peacock" }, { k: "tubi", n: "Tubi" }]
    for each w in wanted
        for each p in t.response.results
            nm = ""
            if p.name <> invalid then nm = LCase(p.name)
            hit = (Instr(1, nm, w.k) > 0)
            if w.k = "max" then hit = (nm = "max" or nm = "hbo max")
            if hit and Instr(1, nm, "ads") = 0 and Instr(1, nm, "channel") = 0
                out.push({ id: p.id, name: w.n, logo: rqImage(p.logoPath, "w92") })
                exit for
            end if
        end for
    end for
    m.provs[t.tag] = out
end sub

function discoverCards(t as object) as object
    cards = []
    if t.ok and t.response.results <> invalid
        for each r in t.response.results
            if r.mediaType = "movie" or r.mediaType = "tv" then cards.push(rqMediaCard(r))
            ' upcoming movies come without mediaType
            if r.mediaType = invalid and r.title <> invalid
                r.mediaType = "movie"
                cards.push(rqMediaCard(r))
            else if r.mediaType = invalid and r.name <> invalid
                r.mediaType = "tv"
                cards.push(rqMediaCard(r))
            end if
        end for
    end if
    return cards
end function

sub onMine(event as object)
    t = taskFrom(event)
    m.mineBusy = false
    if checkProblem(t) then return
    ' a server hiccup must not wipe the list that is already on screen
    if not t.ok and m.cards["mine"] <> invalid then return
    cards = []
    if t.ok and t.response.results <> invalid
        for each r in t.response.results
            cards.push(rqRequestCard(r.request, r.info))
        end for
    end if
    sig = ""
    for each c in cards
        sig = sig + c.title + "|" + c.chip.text + "|" + c.progress.toStr() + "|" + c.caption + ";"
    end for
    if m.cards["mine"] <> invalid and sig = m.mineSig then return
    m.mineSig = sig
    m.mineActive = false
    for each c in cards
        if c.active = true then m.mineActive = true
    end for
    m.cards["mine"] = cards
    m.ver = m.ver + 1
    paintRail()
    if currentList().key = "mine" then showList()
end sub

' ================================================================ rail

function currentList() as object
    return m.lists[m.railIndex]
end function

sub buildRail()
    m.rail.removeChildrenIndex(m.rail.getChildCount(), 0)
    y = 0
    for each l in m.lists
        g = m.rail.createChild("Group")
        g.translation = [0, y]
        bg = g.createChild("Poster")
        bg.uri = "pkg:/images/requests/glow.png"
        bg.width = 400
        bg.height = 66
        ic = g.createChild("Poster")
        ic.uri = "pkg:/images/requests/" + l.icon + ".png"
        ic.width = 28
        ic.height = 28
        ic.translation = [24, 19]
        lab = g.createChild("Label")
        ' upright and brighter: the grey italic list was hard to read from the couch (UX review item 36)
        lab.font = hFont("bold", 30)
        lab.text = l.name
        lab.width = 270
        lab.height = 66
        lab.vertAlign = "center"
        lab.translation = [70, 0]
        cnt = g.createChild("Label")
        cnt.font = hFont("bold", 28)
        cnt.width = 360
        cnt.height = 66
        cnt.horizAlign = "right"
        cnt.vertAlign = "center"
        bar = g.createChild("Rectangle")
        bar.width = 3
        bar.height = 66
        bar.color = "0xE0B34AFF"
        y = y + 76
    end for
    paintRail()
end sub

' No pills: the chosen list gets a soft gold glow, a thin gold bar on its left and gold icon;
' the glow is brighter while the rail has focus.
sub paintRail()
    for i = 0 to m.lists.count() - 1
        g = m.rail.getChild(i)
        if g = invalid then return
        bg = g.getChild(0)
        ic = g.getChild(1)
        lab = g.getChild(2)
        cnt = g.getChild(3)
        bar = g.getChild(4)
        sel = (i = m.railIndex)
        bg.visible = sel
        bar.visible = sel
        if sel
            if m.focused and m.zone = "rail" then bg.blendColor = "0xE0B34A40" else bg.blendColor = "0xE0B34A1F"
            ic.blendColor = "0xE0B34AFF"
            lab.color = "0xEDE6CAFF"
            cnt.color = "0xE0B34AFF"
        else
            ic.blendColor = "0xB5AF8CFF"
            lab.color = "0xD5CFAFFF"
            cnt.color = "0xB5AF8CFF"
        end if
        k = m.lists[i].key
        c = m.cards[k]
        if c <> invalid and k <> "search" and k <> "music" then cnt.text = c.count().toStr() else cnt.text = ""
    end for
end sub

' Show what the rail points at (also while just passing over it)
sub showList()
    l = currentList()
    m.searchPanel.visible = (l.key = "search")
    m.musicPanel.visible = (l.key = "music")
    m.gridClip.visible = (l.key <> "search" and l.key <> "music")
    isNew = (l.key = "new")
    filt = isFilterable(l.key)
    m.tabs.visible = isNew
    m.filterBar.visible = filt
    if filt then paintBar()
    if isNew or filt
        m.gridClip.translation = [540, 210]
        m.gridClip.clippingRect = [-14, -14, 1310, 740]
        m.empty.translation = [540, 230]
        if isNew then paintTabs()
    else
        m.gridClip.translation = [540, 140]
        m.gridClip.clippingRect = [-14, -14, 1310, 800]
        m.empty.translation = [540, 160]
    end if
    m.empty.text = ""
    if l.key = "search"
        setHeader("SEARCH OVERSEERR", "", "")
        setHeadTitle("")
        paintResults()
        return
    end if
    if l.key = "music"
        setHeader("MUSIC · LIDARR", "", "Request music")
        return
    end if
    buildGrid()
    if m.zone <> "grid" then setHeader(l.about, "", l.name)
    if m.problem <> "" and m.cards[l.key] = invalid
        m.empty.text = m.problem
    else if m.cards[l.key] = invalid and l.key = "new"
        if m.global.plexServer = invalid or m.global.plexServer = "" then m.empty.text = "Sign in to Plex to see what's new." else hWaitOn(m.empty, "Plex")
    else if m.cards[l.key] = invalid
        hWaitOn(m.empty, "Overseerr")
    else if m.cards[l.key].count() = 0
        if l.key = "mine"
            m.empty.text = "No requests yet. Pick something in Trending or Search and press OK."
        else if l.key = "new"
            m.empty.text = "Nothing new here yet. Things you request show up here once they've downloaded."
        else if isFilterable(l.key) and m.listError[l.key] <> invalid and m.listError[l.key] <> ""
            m.empty.text = m.listError[l.key] + " Press * to change the filters."
        else if isFilterable(l.key) and filtersActive(l.key)
            m.empty.text = "Nothing matches those filters. Press * to change them."
        else
            m.empty.text = "Nothing here right now."
        end if
    end if
end sub

' Header title: 60, then 50, then 40 on one line; longer still scrolls
sub setHeadTitle(t as string)
    drop = hFitTitle(m.title, t, "caps", [60, 50, 40], 1280)
    m.title.translation = [0, 34 + drop]
end sub

sub setHeader(eyebrow as string, rating as string, title as string)
    m.eyebrow.text = eyebrow
    setHeadTitle(UCase(title))
    has = (rating <> "")
    m.star.visible = has
    m.rating.visible = has
    if has
        x = m.eyebrow.boundingRect().width + 14
        m.star.translation = [x, 4]
        m.rating.translation = [x + 30, 0]
        m.rating.text = rating
    end if
end sub

' ================================================================ grid

sub buildGrid()
    key = currentList().key
    cards = m.cards[key]
    stamp = key + "|" + m.ver.toStr()
    ' fresh counts how many times page 1 has arrived: new results rebuild the grid, later pages only add to it
    if isDiscover(key) and m.gen[key] <> invalid
        fr = 0
        if m.fresh[key] <> invalid then fr = m.fresh[key]
        stamp = key + "|g" + m.gen[key].toStr() + "|f" + fr.toStr()
    end if
    if stamp = m.builtFor and cards <> invalid
        ' same list, maybe more pages: paintGrid adds whatever rows are now near the screen
        paintGrid()
        return
    end if
    m.builtFor = stamp
    m.grid.removeChildrenIndex(m.grid.getChildCount(), 0)
    m.nodes = {}
    if cards = invalid then return
    if m.gridIndex >= cards.count() then m.gridIndex = 0
    paintGrid()
end sub

' Your requests carries a title and a status line under each bar, so its rows sit further apart
function gridPitchY() as integer
    if currentList().key = "mine" then return 410
    return m.pitchY
end function

' Cards are made only for the rows near the screen (a few rows either side of the focused one), so a list can
' run to thousands of titles without thousands of nodes.
sub paintGrid()
    cards = m.cards[currentList().key]
    if cards = invalid then return
    row = Int(m.gridIndex / m.cols)
    ' keep the focused row as the first or second row on screen
    top = row - 1
    if top < 0 then top = 0
    m.grid.translation = [0, -top * gridPitchY()]
    lo = (top - 2) * m.cols
    hi = (top + 6) * m.cols - 1
    if lo < 0 then lo = 0
    if hi > cards.count() - 1 then hi = cards.count() - 1
    gone = []
    for each k in m.nodes
        i = Val(k)
        if i < lo or i > hi then gone.push(k)
    end for
    for each k in gone
        m.grid.removeChild(m.nodes[k])
        m.nodes.delete(k)
    end for
    for i = lo to hi
        k = i.toStr()
        c = m.nodes[k]
        if c = invalid
            c = m.grid.createChild("ReqCard")
            c.translation = [(i mod m.cols) * m.pitchX, Int(i / m.cols) * gridPitchY()]
            c.card = cards[i]
            m.nodes[k] = c
        end if
        r = Int(i / m.cols)
        c.focused = (m.focused and m.zone = "grid" and i = m.gridIndex)
        if r >= top - 1 and r <= top + 3 then c.load = true
    end for
    if m.zone = "grid"
        showCardInfo()
        if cards.count() - m.gridIndex <= m.cols * 3 then maybeMore(currentList().key)
    end if
end sub

function currentCard() as object
    cards = m.cards[currentList().key]
    if cards = invalid or m.gridIndex >= cards.count() then return invalid
    return cards[m.gridIndex]
end function

sub showCardInfo()
    c = currentCard()
    if c = invalid then return
    if c.kind = "plex"
        setHeader(rqArrivedEyebrow(c.data), "", c.title)
        return
    end if
    d = withDetails(c.data)
    setHeader(rqEyebrow(d), rqRating(d.rating), d.title)
    m.top.findNode("detailTimer").control = "stop"
    m.top.findNode("detailTimer").control = "start"
end sub

' Merge cached details (runtime, seasons) into card data
function withDetails(d as object) as object
    x = m.details[d.mediaType + d.id.toStr()]
    if x = invalid then return d
    out = {}
    out.Append(d)
    if x.runtime <> invalid then out.runtime = x.runtime
    if x.numberOfSeasons <> invalid then out.seasons = x.numberOfSeasons
    return out
end function

' Fetch details for the focused title after a short pause
sub onDetailTimer()
    c = focusedMedia()
    if c = invalid then return
    d = c.data
    if m.details[d.mediaType + d.id.toStr()] <> invalid then return
    oApi("GET", "/api/v1/" + d.mediaType + "/" + d.id.toStr(), invalid, invalid, "onDetails", d.mediaType + d.id.toStr())
end sub

sub onDetails(event as object)
    t = taskFrom(event)
    if not t.ok
        if m.wantPopup = t.tag
            m.wantPopup = ""
            flash("warn", "Couldn't open that title", "Overseerr said error " + t.status.toStr())
        end if
        return
    end if
    m.details[t.tag] = t.response
    if m.zone = "grid" then showCardInfo()
    if m.wantPopup = t.tag then openPopupFor(m.wantCard)
end sub

function focusedMedia() as object
    c = invalid
    if m.zone = "grid" then c = currentCard()
    if m.zone = "results" then c = currentResult()
    if c = invalid or c.kind <> "media" then return invalid
    return c
end function

' ================================================================ search

sub onSearchTerm()
    term = m.top.searchTerm.Trim()
    if term = "" then return
    m.railIndex = 0
    m.zone = "kb"
    paintRail()
    showList()
    m.kb.text = term
    runSearch()
    refreshFocus()
end sub

sub onKbText()
    m.top.findNode("searchTimer").control = "stop"
    m.top.findNode("searchTimer").control = "start"
end sub

sub runSearch()
    q = m.kb.text
    if q = invalid then q = ""
    q = q.Trim()
    if q = m.query and m.cards["search"] <> invalid then return
    m.query = q
    if q = ""
        m.cards["search"] = []
        paintResults()
        return
    end if
    m.resultsHead.text = "Searching…"
    oApi("GET", "/api/v1/search", { query: q, page: "1" }, invalid, "onSearch", q)
end sub

sub onSearch(event as object)
    t = taskFrom(event)
    if t.tag <> m.query then return
    if checkProblem(t) then return
    m.cards["search"] = discoverCards(t)
    m.resIndex = 0
    paintResults()
end sub

function currentResult() as object
    r = m.cards["search"]
    if r = invalid or m.resIndex >= r.count() then return invalid
    return r[m.resIndex]
end function

sub paintResults()
    m.results.removeChildrenIndex(m.results.getChildCount(), 0)
    r = m.cards["search"]
    if r = invalid then r = []
    if m.query = ""
        m.resultsHead.text = "Type a few letters"
    else if r.count() = 0
        m.resultsHead.text = "Nothing found for " + Chr(8220) + m.query + Chr(8221)
    else
        m.resultsHead.text = "Results · " + r.count().toStr()
    end if
    first = m.resIndex - 4
    if first < 0 then first = 0
    y = 0
    for i = first to r.count() - 1
        if y > 700 then exit for
        c = r[i]
        g = m.results.createChild("Group")
        g.translation = [0, y]
        on = (m.focused and m.zone = "results" and i = m.resIndex)
        if on
            ring = g.createChild("Poster")
            ring.uri = "pkg:/images/ring.9.png"
            ring.blendColor = "0xE0B34AFF"
            ring.translation = [-10, -6]
            ring.width = 710
            ring.height = 136
        end if
        pb = g.createChild("Rectangle")
        pb.width = 72
        pb.height = 108
        pb.translation = [8, 8]
        pb.color = "0x1D2418FF"
        p = g.createChild("Poster")
        p.width = 72
        p.height = 108
        p.translation = [8, 8]
        p.loadDisplayMode = "scaleToZoom"
        p.uri = c.image
        t = g.createChild("Label")
        t.font = hFont("bold", 30)
        t.text = c.title
        t.width = 380
        t.translation = [104, 24]
        s = g.createChild("Label")
        s.font = hFont("regular", 22)
        s.color = "0xB5AF8CFF"
        if c.data.mediaType = "tv" then kind = "Show" else kind = "Movie"
        if c.data.year <> "" then kind = kind + " · " + c.data.year
        s.text = kind
        s.translation = [104, 66]
        ch = g.createChild("ReqCard")
        ch.card = { kind: "chiponly", chip: c.chip }
        ch.translation = [500, 52 - 270]
        y = y + 132
    end for
end sub

' ================================================================ opening a card

sub openCard(c as object)
    if c = invalid then return
    if c.kind = "search"
        m.railIndex = 0
        m.zone = "kb"
        refreshFocus()
        return
    end if
    if c.kind = "music"
        m.top.request = { action: "musicView", mode: "request" }
        return
    end if
    if c.kind = "plex"
        it = c.data.item
        if c.data.kind = "music"
            m.top.request = { action: "musicView", mode: "artist", artistId: it.ArtistId, albumId: it.Id }
        else
            m.top.request = { action: "details", item: it }
        end if
        return
    end if
    d = c.data
    rs = rqNum(d.requestStatus)
    if d.mediaStatus = 5 or (rs > 0 and d.mediaStatus = 4 and d.mediaType = "movie")
        openInPlex(d)
        return
    end if
    key = d.mediaType + d.id.toStr()
    if m.details[key] = invalid and d.mediaType = "tv"
        ' the season list needs the show's details first
        m.wantPopup = key
        m.wantCard = c
        oApi("GET", "/api/v1/tv/" + d.id.toStr(), invalid, invalid, "onDetails", key)
        flash("clock", "Opening " + d.title + "…", "")
        return
    end if
    openPopupFor(c)
end sub

sub openPopupFor(c as object)
    m.wantPopup = ""
    d = withDetails(c.data)
    m.popCard = c
    items = []
    overview = d.overview
    if d.note <> invalid then overview = d.note
    rs = rqNum(d.requestStatus)
    ' a request of yours (it has an id) that is not already playable can be cancelled or removed
    canCancel = (d.requestId <> invalid and rs >= 1 and d.mediaStatus <> 5 and d.mediaStatus <> 4)
    if canCancel and rs <= 2 then items.push({ label: "Cancel request", icon: "cancel", tag: "cancel" })
    if rs = 1
        ' waiting for approval: nothing else to offer
    else if d.mediaStatus = 2 or d.mediaStatus = 3
        if rs < 0 then overview = "Already requested and on its way. " + nz(d.overview)
    else if rs = 3 or rs = 4 or rs < 0
        ' not asked yet, or declined or failed: offer to ask (again)
        addRequestItems(items, d)
    end if
    if canCancel and rs > 2 then items.push({ label: "Remove request", icon: "cancel", tag: "cancel" })
    if d.mediaStatus = 5 or d.mediaStatus = 4 then items.push({ label: "Open in Plex", icon: "play", tag: "plex" })
    items.push({ label: "More like this", icon: "spark", tag: "like" })
    items.push({ label: "Close", icon: "close", tag: "back" })
    showPopup({ eyebrow: rqEyebrow(d), rating: rqRating(d.rating), title: d.title, overview: overview, poster: rqImage(d.poster, "w342"), items: items, hints: [{ icon: "back", text: "Back to close" }] })
end sub

function nz(s as dynamic) as string
    if s = invalid then return ""
    return s
end function

sub addRequestItems(items as object, d as object)
    if d.mediaType = "tv"
        x = m.details["tv" + d.id.toStr()]
        latest = -1
        if x <> invalid then latest = rqLatestSeason(rqSeasons(x))
        if d.mediaStatus = 4
            items.push({ label: "Request the rest", icon: "layers", tag: "all" })
        else
            items.push({ label: "Request all seasons", icon: "layers", tag: "all" })
        end if
        if latest > 0 then items.push({ label: "Latest season", sub: "Season " + latest.toStr(), icon: "latest", tag: "s" + latest.toStr() })
        items.push({ label: "Choose seasons…", icon: "list", tag: "choose" })
    else
        items.push({ label: "Request", icon: "plus", tag: "movie" })
    end if
end sub

sub showPopup(model as object)
    closePopup()
    p = m.popupHolder.createChild("ReqPopup")
    p.model = model
    p.observeField("picked", "onPicked")
    m.popup = p
    m.zoneBeforePopup = m.zone
    m.zone = "popup"
    ' Rotten Tomatoes critics score (Overseerr looks it up per title)
    c = m.popCard
    if c <> invalid and c.kind = "media" and c.data.id <> invalid
        rk = c.data.mediaType + c.data.id.toStr()
        if m.rt[rk] <> invalid
            if m.rt[rk] <> "" then p.callFunc("setRt", m.rt[rk])
        else
            path = "/api/v1/movie/" + c.data.id.toStr() + "/ratingscombined"
            if c.data.mediaType = "tv" then path = "/api/v1/tv/" + c.data.id.toStr() + "/ratings"
            oApi("GET", path, invalid, invalid, "onRt", rk)
        end if
    end if
end sub

sub onRt(event as object)
    t = taskFrom(event)
    text = ""
    if t.ok and t.response <> invalid
        r = t.response
        if r.rt <> invalid then r = r.rt
        if r.criticsScore <> invalid then text = "ROTTEN TOMATOES " + Int(r.criticsScore).toStr() + "%"
    end if
    m.rt[t.tag] = text
    c = m.popCard
    if m.popup <> invalid and text <> "" and c <> invalid and c.data.mediaType + c.data.id.toStr() = t.tag then m.popup.callFunc("setRt", text)
end sub

sub closePopup()
    if m.popup <> invalid
        m.popupHolder.removeChild(m.popup)
        m.popup = invalid
        m.zone = m.zoneBeforePopup
        refreshFocus()
    end if
end sub

sub onPicked()
    a = m.popup.picked
    c = m.popCard
    d = c.data
    if a = "toggle"
        n = m.popup.callFunc("checked", invalid).count()
        label = "Request " + n.toStr() + " season"
        if n <> 1 then label = label + "s"
        m.popup.callFunc("setLabel", { tag: "send", label: label })
        return
    end if
    if a = "send"
        nums = []
        for each t in m.popup.callFunc("checked", invalid)
            nums.push(Mid(t, 2).toInt())
        end for
        if nums.count() = 0 then return
        closePopup()
        startRequest(c, nums)
        return
    end if
    closePopup()
    if a = "movie"
        startRequest(c, invalid)
    else if a = "all"
        startRequest(c, "all")
    else if Left(a, 1) = "s"
        startRequest(c, [Mid(a, 2).toInt()])
    else if a = "choose"
        chooseSeasons(c)
    else if a = "cancel"
        confirmCancel(c)
    else if a = "cancelyes"
        oApi("DELETE", "/api/v1/request/" + d.requestId.toStr(), invalid, invalid, "onCancelled", d.title)
    else if a = "like"
        moreLike(d)
    else if a = "plex"
        openInPlex(d)
    end if
end sub

' One question before a request is deleted, so a slip of the thumb does not cancel it
sub confirmCancel(c as object)
    d = c.data
    word = "Cancel"
    if rqNum(d.requestStatus) > 2 then word = "Remove"
    items = [
        { label: "Yes, " + LCase(word) + " it", icon: "cancel", tag: "cancelyes" }
        { label: "Keep it", icon: "check", tag: "back" }
    ]
    m.popCard = c
    showPopup({ eyebrow: UCase(word) + " REQUEST", rating: "", title: d.title, overview: "This stops the request in Overseerr. Anything already downloaded stays in Plex.", poster: rqImage(d.poster, "w342"), items: items, hints: [{ icon: "back", text: "Back to keep it" }] })
end sub

sub chooseSeasons(c as object)
    d = c.data
    x = m.details["tv" + d.id.toStr()]
    if x = invalid then return
    items = []
    for each s in rqSeasons(x)
        locked = (s.tag <> "")
        items.push({ label: s.label, sub: s.sub, check: locked, locked: locked, right: s.tag, tag: "s" + s.number.toStr() })
    end for
    items.push({ label: "Request 0 seasons", icon: "plus", tag: "send" })
    items.push({ label: "Cancel", icon: "close", tag: "back" })
    m.popCard = c
    showPopup({ eyebrow: "CHOOSE SEASONS", rating: "", title: d.title, overview: "", poster: rqImage(d.poster, "w342"), items: items, hints: [{ icon: "back", text: "Back to close" }] })
end sub

' ================================================================ request with undo

' seasons: invalid for a movie, "all", or an array of season numbers
sub startRequest(c as object, seasons as dynamic)
    if m.pending <> invalid then sendPending()
    d = c.data
    body = { mediaType: d.mediaType, mediaId: d.id }
    if seasons <> invalid then body.seasons = seasons
    m.pending = { body: body, card: c, list: currentList().key, index: m.gridIndex, left: 3, prevChip: c.chip, prevStatus: d.mediaStatus }
    ' mark the card itself (not just the drawn chip) so a second OK offers no "Request" and sends no duplicate
    c.chip = rqChip("Requested", "clock", "gold")
    d.mediaStatus = 2
    setChip(c, c.chip)
    showUndo()
    m.top.findNode("undoTimer").control = "start"
end sub

sub showUndo()
    p = m.pending
    m.top.findNode("toastIcon").uri = "pkg:/images/requests/back.png"
    m.toastText.text = "Requesting " + p.card.data.title + " · " + p.left.toStr()
    m.toastHint.text = "Back to undo"
    layoutToast()
    m.top.findNode("toastTimer").control = "stop"
end sub

sub onUndoTick()
    if m.pending = invalid then return
    m.pending.left = m.pending.left - 1
    if m.pending.left <= 0 then sendPending() else showUndo()
end sub

sub sendPending()
    p = m.pending
    m.pending = invalid
    m.top.findNode("undoTimer").control = "stop"
    if m.sent = invalid then m.sent = {}
    m.sent[p.card.data.title] = p
    oApi("POST", "/api/v1/request", invalid, rqRequestJson(p.body), "onRequested", p.card.data.title)
    m.toast.visible = false
end sub

sub undoPending()
    p = m.pending
    m.pending = invalid
    m.top.findNode("undoTimer").control = "stop"
    p.card.chip = p.prevChip
    p.card.data.mediaStatus = p.prevStatus
    setChip(p.card, p.prevChip)
    flash("close", "Not requested: " + p.card.data.title, "")
end sub

sub onRequested(event as object)
    t = taskFrom(event)
    if m.sent <> invalid and t.ok then m.sent.delete(t.tag)
    if t.ok
        flash("check", "Requested " + t.tag, "")
        ' start the download now: Radarr/Sonarr search immediately
        hArrKick(t.response)
        loadMine()
        return
    end if
    p = invalid
    if m.sent <> invalid then p = m.sent[t.tag]
    if t.status = 409
        flash("check", t.tag + " is already requested", "")
        loadMine()
        return
    end if
    ' put the card back so it can be asked for again
    if p <> invalid
        p.card.chip = p.prevChip
        p.card.data.mediaStatus = p.prevStatus
        setChip(p.card, p.prevChip)
    end if
    why = ""
    if t.response <> invalid and t.response.message <> invalid then why = t.response.message
    if why = "" then why = "Overseerr said error " + t.status.toStr()
    flash("warn", "Couldn't request " + t.tag, why)
end sub

sub onCancelled(event as object)
    t = taskFrom(event)
    ' 404 means Overseerr no longer has it, which is what was wanted
    if t.ok or t.status = 404
        flash("check", "Cancelled " + t.tag, "")
        ' take it off the screen now; the slow ask below may still hold the old list
        if m.cards["mine"] <> invalid
            keepCards = []
            for each c in m.cards["mine"]
                if c.title <> t.tag then keepCards.push(c)
            end for
            m.cards["mine"] = keepCards
            m.mineSig = ""
            m.ver = m.ver + 1
            if currentList().key = "mine" then showList()
        end if
    else
        flash("warn", "Couldn't cancel " + t.tag, "error " + t.status.toStr())
    end if
    m.mineBusy = false
    loadMine()
end sub


' Redraw one card's chip wherever it is on screen (the card data itself keeps its old chip for undo)
sub setChip(c as object, chip as object)
    for i = 0 to m.grid.getChildCount() - 1
        n = m.grid.getChild(i)
        cc = n.card
        if cc <> invalid and cc.data <> invalid and cc.data.id = c.data.id and cc.data.mediaType = c.data.mediaType
            cc.chip = chip
            n.card = cc
        end if
    end for
end sub

' ================================================================ more like this, Plex

sub moreLike(d as object)
    m.likeKind = d.mediaType
    oApi("GET", "/api/v1/" + d.mediaType + "/" + d.id.toStr() + "/recommendations", { page: "1" }, invalid, "onLike", d.title)
end sub

sub onLike(event as object)
    t = taskFrom(event)
    if checkProblem(t) then return
    cards = []
    if t.ok and t.response.results <> invalid
        for each r in t.response.results
            if r.mediaType = invalid
                r.mediaType = "movie"
                if m.likeKind <> invalid then r.mediaType = m.likeKind
            end if
            cards.push(rqMediaCard(r))
        end for
    end if
    if cards.count() = 0
        flash("warn", "Overseerr has nothing like " + t.tag, "")
        return
    end if
    entry = { key: "like", icon: "spark", name: "Like " + t.tag, about: "MORE LIKE " + UCase(t.tag) }
    if m.lists[1].key = "like" then m.lists[1] = entry else m.lists = insertAt(m.lists, 1, entry)
    m.cards["like"] = cards
    m.ver = m.ver + 1
    buildRail()
    m.railIndex = 1
    m.gridIndex = 0
    m.zone = "grid"
    refreshFocus()
end sub

function insertAt(list as object, at as integer, item as object) as object
    out = []
    for i = 0 to list.count() - 1
        if i = at then out.push(item)
        out.push(list[i])
    end for
    return out
end function

sub openInPlex(d as object)
    m.plexWant = d
    hPlex("search", { query: d.title, limit: 20 }, "onPlexFound", d.title)
end sub

sub onPlexFound(event as object)
    t = hTaskFrom(event)
    d = m.plexWant
    if d = invalid then return
    want = "Movie"
    if d.mediaType = "tv" then want = "Series"
    best = invalid
    if t.ok and t.response.Items <> invalid
        for each it in t.response.Items
            if it.Type = want
                y = ""
                if it.ProductionYear <> invalid then y = it.ProductionYear.toStr()
                if best = invalid or y = d.year then best = it
                if y = d.year then exit for
            end if
        end for
    end if
    if best = invalid
        flash("warn", "Couldn't find " + d.title + " in Plex yet", "Plex may still be scanning it")
        return
    end if
    m.top.request = { action: "details", item: best }
end sub

' ================================================================ toast

sub flash(icon as string, text as string, hint as string)
    if m.pending <> invalid then return
    m.top.findNode("toastIcon").uri = "pkg:/images/requests/" + icon + ".png"
    m.toastText.text = text
    m.toastHint.text = hint
    layoutToast()
    m.top.findNode("toastTimer").control = "stop"
    m.top.findNode("toastTimer").control = "start"
end sub

sub layoutToast()
    w = m.toastText.boundingRect().width
    m.toastHint.translation = [72 + w + 20, 0]
    hw = 0
    if m.toastHint.text <> "" then hw = m.toastHint.boundingRect().width + 20
    m.top.findNode("toastBg").width = 72 + w + hw + 30
    m.toast.visible = true
end sub

sub onToastDone()
    if m.pending = invalid then m.toast.visible = false
end sub

' ================================================================ setup (no key yet)

sub showSetup(problem as string)
    m.top.ready = true
    m.loaded = false
    m.cards = {}
    m.top.findNode("main").visible = false
    ip = "<TV IP>"
    addrs = CreateObject("roDeviceInfo").GetIPAddrs()
    for each k in addrs
        ip = addrs[k]
    end for
    q = Chr(34)
    lines = []
    if problem <> "" then lines.push(problem) else lines.push("Hearth needs your Overseerr API key, once. It stays on this TV.")
    lines.push("")
    lines.push("Find it in Overseerr under Settings, General, API Key. With this screen open, run this in Terminal on your Mac:")
    lines.push("")
    lines.push("curl -X POST -G --data-urlencode " + q + "overseerrKey=YOUR-KEY" + q + " http://" + ip + ":8060/input")
    lines.push("")
    lines.push("Or type it on the keyboard here (the phone remote can paste it), then choose Save key.")
    m.setupText.text = lines.join(Chr(10))
    m.setup.visible = true
    ' a sheet or popup left open would sit on top of the key screen and swallow its keys
    closeSheet()
    if m.popup <> invalid
        m.popupHolder.removeChild(m.popup)
        m.popup = invalid
    end if
    if m.zone <> "save" then m.zone = "setup"
    if m.focused then refreshFocus()
end sub

sub saveTypedKey()
    k = m.keyKb.text
    if k = invalid then return
    k = k.Trim()
    if k = "" then return
    m.reg.Write("overseerrKey", k)
    m.reg.Flush()
    m.zone = "rail"
    m.global.overseerrKey = k
end sub

' ================================================================ focus and keys

' Overseerr was down or errored while the lists loaded: ask again when the room is entered
sub retryLists()
    if m.problem = "" or m.setup.visible then return
    m.problem = ""
    for each l in m.lists
        if l.path <> invalid and m.cards[l.key] = invalid then loadList(l.key)
    end for
    if m.genres.movie.count() = 0 then oApi("GET", "/api/v1/genres/movie", invalid, invalid, "onGenres", "movie")
    if m.genres.tv.count() = 0 then oApi("GET", "/api/v1/genres/tv", invalid, invalid, "onGenres", "tv")
end sub

sub focusIn(unused as dynamic)
    retryLists()
    touchList(currentList().key)
    m.focused = true
    m.top.setFocus(true)
    refreshFocus()
end sub

' Home's "Newly downloaded" card lands here: the New tab, All, with focus on the newest poster
sub openNew(unused as dynamic)
    if m.setup.visible then return
    for i = 0 to m.lists.count() - 1
        if m.lists[i].key = "new" then m.railIndex = i
    end for
    m.newTab = 0
    m.gridIndex = 0
    if m.newAll <> invalid then filterNew()
    paintRail()
    showList()
    c = m.cards["new"]
    if c <> invalid and c.count() > 0 then m.zone = "grid" else m.zone = "rail"
    refreshFocus()
end sub

sub refreshFocus()
    if m.setup.visible
        m.keyKb.active = (m.focused and m.zone = "setup")
        m.saveKey.focused = (m.focused and m.zone = "save")
        return
    end if
    m.kb.active = (m.focused and m.zone = "kb")
    paintRail()
    showList()
    if m.zone = "grid" then paintGrid()
    if m.zone = "rail" then paintGrid()
end sub

sub toPills()
    m.focused = false
    m.zone = "rail"
    refreshFocus()
    m.top.request = { action: "pills" }
end sub

function hKeyInner(key as string, press as boolean) as boolean
    if not press then return false
    ' Play on a new movie plays it straight away
    if key = "play" and m.zone = "grid" and currentList().key = "new"
        c = currentCard()
        if c <> invalid and c.kind = "plex" and c.data.item.Type = "Movie"
            m.top.request = { action: "play", item: c.data.item, resume: true }
            return true
        end if
    end if
    if hMediaKey(key) then return false
    if m.pending <> invalid and key = "back"
        undoPending()
        return true
    end if
    z = m.zone
    if z = "popup"
        m.popup.callFunc("handleKey", key)
        return true
    end if
    if z = "sheet"
        if m.sheet = invalid
            print "[hearth-filter] sheet key with no sheet; back to the bar"
            m.zone = "bar"
            refreshFocus()
            return true
        end if
        m.sheet.callFunc("handleKey", key)
        return true
    end if
    if z = "bar" then return barKey(key)
    if z = "setup"
        edge = m.keyKb.callFunc("handleKey", key)
        if edge = "up" or edge = "back"
            toPills()
        else if edge = "down"
            m.zone = "save"
            refreshFocus()
        end if
        return true
    end if
    if z = "save"
        if key = "OK"
            saveTypedKey()
        else if key = "up"
            m.zone = "setup"
            refreshFocus()
        else if key = "back"
            toPills()
        end if
        return true
    end if
    if z = "rail" then return railKey(key)
    if z = "grid" then return gridKey(key)
    if z = "tabs" then return tabsKey(key)
    if z = "kb"
        edge = m.kb.callFunc("handleKey", key)
        if edge = "left" or edge = "back"
            m.zone = "rail"
            refreshFocus()
        else if edge = "up"
            toPills()
        else if edge = "right"
            r = m.cards["search"]
            if r <> invalid and r.count() > 0
                m.zone = "results"
                paintResults()
                m.kb.active = false
            end if
        end if
        return true
    end if
    if z = "results"
        r = m.cards["search"]
        if Left(key, 4) = "Lit_" or key = "backspace"
            m.kb.callFunc("handleKey", key)
            return true
        end if
        if key = "up" and m.resIndex > 0
            m.resIndex = m.resIndex - 1
        else if key = "down" and r <> invalid and m.resIndex < r.count() - 1
            m.resIndex = m.resIndex + 1
        else if key = "left" or key = "back" or key = "up"
            m.zone = "kb"
            m.kb.active = true
        else if key = "OK" or key = "options"
            openCard(currentResult())
        end if
        paintResults()
        return true
    end if
    return true
end function

function railKey(key as string) as boolean
    n = m.lists.count()
    if key = "up"
        if m.railIndex = 0
            toPills()
            return true
        end if
        m.railIndex = m.railIndex - 1
        m.gridIndex = 0
        touchList(currentList().key)
    else if key = "down"
        if m.railIndex < n - 1
            m.railIndex = m.railIndex + 1
            m.gridIndex = 0
            touchList(currentList().key)
        end if
    else if key = "back"
        toPills()
        return true
    else if key = "options" and isFilterable(currentList().key)
        openSheet()
        return true
    else if key = "right" or key = "OK"
        k = currentList().key
        if k = "search"
            m.zone = "kb"
        else if k = "music"
            if key = "OK" then m.top.request = { action: "musicView", mode: "request" }
            return true
        else if m.cards[k] <> invalid and m.cards[k].count() > 0
            m.zone = "grid"
        else if k = "new" and m.newAll <> invalid
            m.zone = "tabs"
        else if isFilterable(k) and m.cards[k] <> invalid
            m.zone = "bar"
        end if
    else
        return true
    end if
    refreshFocus()
    return true
end function

function gridKey(key as string) as boolean
    cards = m.cards[currentList().key]
    n = 0
    if cards <> invalid then n = cards.count()
    i = m.gridIndex
    col = i mod m.cols
    if key = "left"
        if col = 0
            m.zone = "rail"
            refreshFocus()
            return true
        end if
        m.gridIndex = i - 1
    else if key = "right"
        if col < m.cols - 1 and i + 1 < n then m.gridIndex = i + 1
    else if key = "up"
        if i < m.cols and currentList().key = "new"
            m.zone = "tabs"
            refreshFocus()
            return true
        end if
        if i < m.cols and isFilterable(currentList().key)
            m.zone = "bar"
            refreshFocus()
            return true
        end if
        if i < m.cols
            toPills()
            return true
        end if
        m.gridIndex = i - m.cols
    else if key = "down"
        if i + m.cols < n
            m.gridIndex = i + m.cols
        else if Int(i / m.cols) < Int((n - 1) / m.cols)
            m.gridIndex = n - 1
        end if
    else if key = "back"
        m.zone = "rail"
        refreshFocus()
        return true
    else if key = "options" and isFilterable(currentList().key)
        openSheet()
        return true
    else if key = "OK" or key = "options"
        openCard(currentCard())
        return true
    end if
    paintGrid()
    return true
end function

' ================================================================ filter bar and sheet

function filtersActive(key as string) as boolean
    f = m.filters[key]
    if key = "trending" and f.kind <> "all" then return true
    return f.genres.count() > 0 or f.provider <> "" or f.minRating > 0 or f.sort <> "popular"
end function

function filterSummary(key as string) as string
    f = m.filters[key]
    parts = []
    if key = "trending" and f.kind = "movie" then parts.push("movies")
    if key = "trending" and f.kind = "tv" then parts.push("shows")
    if f.genres.count() > 0 then parts.push(f.genres.join(" + "))
    if f.provider <> ""
        kind = "movie"
        if effKind(key) = "tv" then kind = "tv"
        for each p in m.provs[kind]
            if p.id.toStr() = f.provider then parts.push("on " + p.name)
        end for
    end if
    if f.minRating > 0 then parts.push("rated " + f.minRating.toStr() + ".0+")
    names = { popular: "most popular", rating: "top rated", newest: "newest", az: "A to Z" }
    if key <> "trending" or f.kind <> "all" then parts.push(names[f.sort])
    text = parts.join(" · ")
    if m.busy[key] = true
        if text = "" then return "Asking Overseerr…"
        return "Asking Overseerr… · " + text
    end if
    if filtersActive(key)
        ' keep room for "Filtered · 43 of 100" and the hint on the same line
        if Len(text) > 48 then text = Left(text, 46) + "…"
        return text
    end if
    n = filterCountShown(key)
    if m.totals[key] <> invalid and m.totals[key] > n then n = m.totals[key]
    ' no dangling dot when there is nothing after the count (Trending, walk 2)
    if text = "" then return reqThousands(n) + " titles"
    return reqThousands(n) + " titles · " + text
end function

function filterCountShown(key as string) as integer
    if m.cards[key] = invalid then return 0
    return m.cards[key].count()
end function

' "Filtered · 43 of 100": Trending is narrowed here, so "of" is what was fetched (up to 5 pages);
' movies and shows are narrowed by Overseerr, so "of" is its total for these filters (more than 100 means the cap was hit)
function filterCountLine(key as string) as string
    shown = filterCountShown(key)
    total = m.totals[key]
    if total = invalid or total < shown then total = shown
    return "Filtered · " + reqThousands(total) + " titles"
end function

function reqThousands(n as integer) as string
    s = n.toStr()
    out = ""
    while Len(s) > 3
        out = "," + Right(s, 3) + out
        s = Left(s, Len(s) - 3)
    end while
    return s + out
end function

sub paintBar()
    key = currentList().key
    on = (m.focused and m.zone = "bar")
    bg = m.top.findNode("barBg")
    lab = m.top.findNode("barLabel")
    ico = m.top.findNode("barIcon")
    m.top.findNode("barRing").visible = on
    if on
        bg.blendColor = "0xE0B34AFF"
        lab.color = "0x1F1606FF"
        ico.blendColor = "0x1F1606FF"
    else if filtersActive(key)
        bg.blendColor = "0xE0B34A55"
        lab.color = "0xEDE6CAFF"
        ico.blendColor = "0xEDE6CAFF"
    else
        bg.blendColor = "0xFFFFFF12"
        lab.color = "0xEDE6CAFF"
        ico.blendColor = "0xEDE6CAFF"
    end if
    act = filtersActive(key)
    sum = m.top.findNode("barSum")
    sum.text = filterSummary(key)
    if act then sum.color = "0xEDE6CAFF" else sum.color = "0xB5AF8CFF"
    cnt = m.top.findNode("barCount")
    cnt.visible = act
    if act then cnt.text = filterCountLine(key) else cnt.text = ""
    m.top.findNode("barHintKey").visible = act
    m.top.findNode("barHint").visible = act
end sub

function barKey(key as string) as boolean
    if key = "OK" or key = "options"
        openSheet()
        return true
    else if key = "down"
        c = m.cards[currentList().key]
        if c <> invalid and c.count() > 0 then m.zone = "grid"
    else if key = "up"
        toPills()
        return true
    else if key = "left" or key = "back"
        m.zone = "rail"
    end if
    refreshFocus()
    return true
end function

sub openSheet()
    key = currentList().key
    if not isFilterable(key) then return
    gb = { movie: [], tv: [] }
    for each kind in ["movie", "tv"]
        for each g in m.genres[kind]
            gb[kind].push(g.name)
        end for
    end for
    pb = { movie: m.provs.movie, tv: m.provs.tv }
    closeSheet()
    print "[hearth-filter] open sheet for "; key; " genres "; gb.movie.count(); "/"; gb.tv.count(); " providers "; pb.movie.count(); "/"; pb.tv.count()
    s = m.sheetHolder.createChild("FilterSheet")
    s.config = { title: currentList().name, genresBy: gb, providersBy: pb, pickKind: (key = "trending"), filters: m.filters[key] }
    s.observeField("result", "onSheetResult")
    m.sheet = s
    m.zoneBeforeSheet = m.zone
    m.zone = "sheet"
end sub


sub closeSheet()
    if m.sheet <> invalid
        m.sheetHolder.removeChild(m.sheet)
        m.sheet = invalid
    end if
end sub

sub onSheetResult(event as object)
    f = event.getData()
    key = currentList().key
    old = m.filters[key]
    changed = (FormatJson(f) <> FormatJson(old))
    print "[hearth-filter] sheet closed for "; key; " changed="; changed; " "; FormatJson(f)
    closeSheet()
    m.zone = "bar"
    if changed
        m.filters[key] = f
        m.gridIndex = 0
        loadList(key)
    end if
    refreshFocus()
end sub

function tabsKey(key as string) as boolean
    if key = "left"
        if m.newTab = 0
            m.zone = "rail"
        else
            m.newTab = m.newTab - 1
            m.gridIndex = 0
            filterNew()
        end if
    else if key = "right"
        if m.newTab < m.newTabs.count() - 1
            m.newTab = m.newTab + 1
            m.gridIndex = 0
            filterNew()
        end if
    else if key = "down" or key = "OK"
        c = m.cards["new"]
        if c <> invalid and c.count() > 0 then m.zone = "grid"
    else if key = "up"
        toPills()
        return true
    else if key = "back"
        m.zone = "rail"
    end if
    refreshFocus()
    return true
end function

' menu sound for whatever the handler above took (source/util.brs hKeySfx)
function onKeyEvent(key as string, press as boolean) as boolean
    return hKeySfx(key, press, hKeyInner(key, press))
end function
